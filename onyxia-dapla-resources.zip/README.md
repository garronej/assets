# Custom resources directory

In this directory you can drop the custom resources for your instance.  
To use them in production, create a Zip file with the content of 
this directory and use the `CUSTOM_RESOURCES` environnement
variable. See `.env` file for more infos.